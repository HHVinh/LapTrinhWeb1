function externalFunc(){
    document.getElementById("demo").innerHTML = "Paragraph changed for myScript.js."
}
